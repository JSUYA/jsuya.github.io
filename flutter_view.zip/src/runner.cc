#include "runner.h"
#include "Elementary.h"

#include <app.h>
#include <dlog.h>

#include "generated_plugin_registrant.h"

class App {//}: public FlutterView {
 public:
  bool OnCreate() {

    Evas_Object *parent_window_ = elm_win_add(NULL, NULL, ELM_WIN_BASIC);
    elm_win_autodel_set(parent_window_, EINA_TRUE);
    elm_win_alpha_set(parent_window_, EINA_TRUE);

    Evas_Object *background_ = elm_bg_add(parent_window_);
    evas_object_size_hint_weight_set(background_, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
    evas_object_color_set(background_, 255, 255, 255, 255);
    elm_win_resize_object_add(parent_window_, background_);

    Evas_Object *scr = elm_scroller_add(parent_window_);                                                     
    elm_scroller_bounce_set(scr, EINA_FALSE, EINA_TRUE);
    elm_scroller_policy_set(scr, ELM_SCROLLER_POLICY_OFF, ELM_SCROLLER_POLICY_AUTO);
    evas_object_size_hint_weight_set(scr, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
    elm_win_resize_object_add(parent_window_, scr);
    evas_object_show(scr);

    evas_object_show(background_);
    evas_object_show(parent_window_);

    Evas_Object* box = elm_box_add(parent_window_);
    evas_object_size_hint_weight_set(box, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
    elm_object_content_set(scr, box);

    for(int i = 0; i < 2; i++)
    {
      Evas_Object* but = elm_button_add(box);
      elm_object_text_set(but,"WIN(BG)-SCROLL-BOX");
      evas_object_size_hint_weight_set(but, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
      evas_object_size_hint_align_set(but, EVAS_HINT_FILL, EVAS_HINT_FILL);
      elm_box_pack_end(box, but);
      evas_object_show(but);
    }
 

    FlutterView view;
    view.window_height_ = 500;
    view.parent_ = box;
    view.SetDartEntrypoint("main1"); //Optional, Default is "main"
    view.RunEngine();
    
    if (view.IsRunning()) {
      Evas_Object* image = (Evas_Object*)(view.GetImageHandle());
      evas_object_size_hint_weight_set(image, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
      evas_object_size_hint_align_set(image, EVAS_HINT_FILL, EVAS_HINT_FILL);
      elm_box_pack_end(box, image);
    }
    

    for(int i = 0; i < 2; i++)
    {
      Evas_Object* but = elm_button_add(box);
      elm_object_text_set(but,"WIN(BG)-SCROLL-BOX");
      evas_object_size_hint_weight_set(but, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
      evas_object_size_hint_align_set(but, EVAS_HINT_FILL, EVAS_HINT_FILL);
      elm_box_pack_end(box, but);
      evas_object_show(but);
    }

    FlutterView view2;
    view2.window_height_ = 300;
    view2.parent_ = box;
    view2.SetDartEntrypoint("main2");
    view2.RunEngine();
    
    if (view2.IsRunning()) {
      Evas_Object* image = (Evas_Object*)(view2.GetImageHandle());
      evas_object_size_hint_weight_set(image, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
      evas_object_size_hint_align_set(image, EVAS_HINT_FILL, EVAS_HINT_FILL);
      elm_box_pack_end(box, image);
    }    

    for(int i = 0; i < 10; i++)
    {
      Evas_Object* but = elm_button_add(box);
      elm_object_text_set(but,"WIN(BG)-SCROLL-BOX");
      evas_object_size_hint_weight_set(but, EVAS_HINT_EXPAND, EVAS_HINT_EXPAND);
      evas_object_size_hint_align_set(but, EVAS_HINT_FILL, EVAS_HINT_FILL);
      elm_box_pack_end(box, but);
      evas_object_show(but);
    }

    return true;
  }
};

int main(int argc, char *argv[]) {
  App app;

  ui_app_lifecycle_callback_s lifecycle_cb = {};
  
  lifecycle_cb.create = [](void *data) -> bool {
    App *app = (App *)data;
    return app->OnCreate();
  };

  return ui_app_main(argc, argv, &lifecycle_cb, &app);
}
