import 'package:flutter/material.dart';


import 'package:flutterview_test/item1.dart' as item1;
import 'package:flutterview_test/item2.dart' as item2;

void main() {
  // Nothing to do
}

@pragma('vm:entry-point')
void main1() {
  runApp(const item1.MyApp());
}

@pragma('vm:entry-point')
void main2() {
  runApp(const item2.MyApp());
}